int bar(void)
{
  return 0;
}
