void fooSuffix(void){}
