void fooPath(void){}
