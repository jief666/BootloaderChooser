void fooPathVers(void){}
