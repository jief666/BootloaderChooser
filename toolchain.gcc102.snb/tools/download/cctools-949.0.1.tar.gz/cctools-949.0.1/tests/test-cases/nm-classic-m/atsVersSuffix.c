void atsVersSuffix(void) {}
