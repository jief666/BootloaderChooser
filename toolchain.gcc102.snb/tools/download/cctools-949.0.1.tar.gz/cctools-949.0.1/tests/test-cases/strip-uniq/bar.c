static int debug(void)
{
  return 0;
}

int bar(void)
{
  debug();
  return 0;
}
