static int debug(void)
{
  return 0;
}

int foo(void)
{
  debug();
  return 0;
}
