//
//  apple_version.c
//  stuff
//
//  Created by Michael Trent on 12/20/18.
//

#ifndef CURRENT_PROJECT_VERSION
#define CURRENT_PROJECT_VERSION "cctools-localbuild"
#endif /* CURRENT_PROJECT_VERSION */

const char apple_version[] = "" CURRENT_PROJECT_VERSION;
