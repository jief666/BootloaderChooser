extern
char *
__cxa_demangle(
const char* mangled_name,
char *output_buffer,
size_t *length,
int *status);
