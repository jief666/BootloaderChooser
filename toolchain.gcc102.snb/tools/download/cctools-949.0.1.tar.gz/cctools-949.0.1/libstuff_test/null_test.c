//
//  null_test.cpp
//  libstuff_test
//
//  Created by Michael Trent on 1/19/19.
//

#include "test_main.h"

static void test_null(void)
{
  ;
}

int test_main(void)
{
  return test_add("test harness initialization", test_null);
}
